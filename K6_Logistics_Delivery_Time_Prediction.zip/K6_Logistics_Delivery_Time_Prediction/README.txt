# K6 – Logistics Delivery Time Prediction

## Project objective
Predict parcel delivery time in minutes using regression.

## Files
- `K6_Delivery_Time_Prediction.ipynb` – complete Jupyter Notebook
- `logistics_delivery_dataset.csv` – practice dataset (1,200 rows)
- `requirements.txt` – Python dependencies

## Requirements
- Python 3.10 or newer (Python 3.11 recommended)
- Visual Studio Code
- VS Code extensions: Python and Jupyter

## Setup on Windows (VS Code)

1. Extract this ZIP file.
2. Open VS Code.
3. Select **File → Open Folder** and open the extracted `K6_Logistics_Delivery_Time_Prediction` folder.
4. Open Terminal → New Terminal.
5. (Recommended) Create a virtual environment:

   ```powershell
   py -3.11 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run this for the current terminal only:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\.venv\Scripts\Activate.ps1
   ```

6. Install the packages:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

7. Open `K6_Delivery_Time_Prediction.ipynb`.
8. Click **Select Kernel** (top-right) → choose the Python interpreter inside `.venv`.
9. Click **Run All** or run cells one by one from the top.

## How to use
The notebook loads `logistics_delivery_dataset.csv` from the same folder. Keep both files together.
At the end, edit the six values in the `new_parcel` cell to predict delivery time for a different parcel.

## Dataset note
The included data is synthetic and generated for educational practice. It is not real logistics-company data. Explain this clearly in your presentation/report.

## Metrics
- MAE: average absolute error, measured in minutes (lower is better).
- RMSE: square-root of mean squared error, measured in minutes (lower is better; large errors are penalised more).
- R²: model score relative to a mean-prediction baseline (closer to 1 is generally better; can be negative).

## Troubleshooting
- `ModuleNotFoundError`: activate `.venv` and run `pip install -r requirements.txt`.
- CSV file not found: make sure VS Code opened the extracted project folder, not just the notebook file.
- Wrong kernel: use Select Kernel and choose `.venv`.
- Notebook cells do not run: install/enable the VS Code Python and Jupyter extensions.
